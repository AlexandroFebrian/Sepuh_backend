<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Session;

class UserController extends Controller
{
    public function login(){
        return view("login");
    }
    public function doLogin(Request $request){
        $username = $request->username;
        $password = $request->password;

        //mengambil nilai dari session
        $users=$request->session()->get('listUser');

        if($users!=null){
            foreach ($users as $index => $user) {
                if($user["username"] == $username && $user["password"]==$password){
                    Cookie::queue(Cookie::make('loginNow',$username,30));
                    Cookie::queue(Cookie::make('counter',$user['rizz_counter'],30));
                    return redirect('/user/home');
                }
            }
        }
        return redirect()->route('login')->with("message","gagal login");

    }

    public function register(){
        return view("register");
    }

    public function doRegist(Request $request){
        if($request->username!=null && $request->password!=null){
            $username = $request->username;
            $password = $request->password;

            //mengambil nilai dari session
            $users=$request->session()->get('listUser');

            if($users!=null){
                $isFound = false;
                foreach ($users as $index => $user) {
                    if($user["username"] == $username){
                        $isFound=true;
                        break;
                    }
                }

                if($isFound){
                    return redirect()->route('register')->with("message","sudah terdaftar");
                }
            }
            $newUser = [
                "username"=>$username,
                "password"=>$password,
                "rizz_counter"=>0
            ];
            //JANGAN LUPA IMPORT SESSION YANG SUPPORT FACADES
            Session::push("listUser",$newUser);
            //flash hanya dapat muncul pada request selanjutnya
            Session::flash("success",1);
            return redirect()->route('register')->with("message","Berhasil register $username");

        }
        return redirect()->route('register')->with("message","gagal register");
    }

    public function home(Request $request){
        return view('home');
    }

    public function counter(Request $request){
        $login=[];
        $index=-1;
        foreach (Session::get('listUser') as $key => $user) {
            if($user['username']=='a'){
                $login = $user;
                $index=$key;
                break;
            }
        }

        $counter = $login['rizz_counter'] +1;
        // dd(Session::get('listUser')[$index]['rizz_counter']);
        //update session dan cookie
        Session::put("listUser.$index.rizz_counter",$counter);
        Cookie::queue('counter',$counter,30);
        return redirect('/user/home');

    }

    public function logout(Request $request){
        Cookie::queue(Cookie::forget('loginNow'));
        Cookie::queue(Cookie::forget('counter'));
        return redirect()->route('login');
    }
}
