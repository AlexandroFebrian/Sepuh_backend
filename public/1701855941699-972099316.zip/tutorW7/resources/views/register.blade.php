<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Register</title>
    <style>
        body{
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }

        form{
            display: flex;
            flex-direction: column;
        }

        #formulir{
            margin: 10%;
        }
    </style>
</head>
<body>
    <div id="formulir">
        <h1>Register</h1>
        @if (session()->has('message') && session()->get('success'))
            <div style="color:green;">{{session()->get('message')}}</div>
        @else
            <?php var_dump(session()->get("listUser"))?>
            <div style="color:red;">{{session()->get('message')}}</div>
        @endif
        <div>
            Form laravel JANGAN LUPA PAKAI CSRF
            <form action="{{route('registing')}}" method="post">
                @csrf
                Username <br>
                <input type="text" name="username" id="">

                Password <br>
                <input type="password" name="password" id="">

                <button>Register</button>
            </form>
            <a href="/user/login">go to Login</a>
        </div>
    </div>

</body>
</html>
