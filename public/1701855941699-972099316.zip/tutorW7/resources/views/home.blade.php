<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <div>Selamat datang, {{/*Cara mendapatkan cookie*/request()->cookie('loginNow')}}, you have {{request()->cookie('counter')}} </div>
    <div><form action="{{route('logout')}}"><button>Logout</button></form></div>
    <div>
        <form action="{{route('counter')}}" method="get">
            <button>Rizz Button</button>
        </form>
    </div>

    <?php dd(session()->get('listUser'))?>
</body>
</html>
