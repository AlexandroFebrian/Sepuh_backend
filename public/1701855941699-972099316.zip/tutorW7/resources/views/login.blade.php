<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>

    <style>
        body{
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }

        form{
            display: flex;
            flex-direction: column;
        }

        #formulir{
            margin: 10%;
        }
    </style>
</head>
<body>
    <div id="formulir">
        <h1>Login</h1>
        @if (session()->has('message'))
            <div style="color:red;">{{session()->get('message')}}</div>
        @endif
        <div>
            Form laravel JANGAN LUPA PAKAI CSRF
            <form action="{{route('doLogin')}}" method="post">

                @csrf
                Username <br>
                <input type="text" name="username" id="">

                Password <br>
                <input type="password" name="password" id="">

                <button>Login</button>
            </form>
            <a href="/user/register">Register</a>
        </div>
        <?php dd(request()->cookie())?>
    </div>
</body>
</html>
