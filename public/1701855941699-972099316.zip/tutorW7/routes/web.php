<?php

use App\Http\Controllers\UserController;
use Illuminate\Routing\RouteGroup;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
Route::get('', function () {
    return redirect()->route('login');
});

Route::prefix('user')->group(function () {
    //login
    Route::get('/login', [UserController::class,"login"])->name('login');
    //memproses login
    Route::post('/doLogin', [UserController::class,"doLogin"])->name("doLogin");

    //Register
    Route::get('/register',[UserController::class,"register"])->name('register');
    //memproses register
    Route::post('/doRegister',[UserController::class,"doRegist"])->name("registing");

    //Home
    Route::get('/home',[UserController::class,"home"]);
});

Route::get('/counter',[UserController::class,"counter"])->name('counter');
Route::get('/logout',[UserController::class,"logout"])->name('logout');
