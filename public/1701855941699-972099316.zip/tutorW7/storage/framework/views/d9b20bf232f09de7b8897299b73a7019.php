<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Register</title>
    <style>
        body{
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }

        form{
            display: flex;
            flex-direction: column;
        }

        #formulir{
            margin: 10%;
        }
    </style>
</head>
<body>
    <div id="formulir">
        <h1>Register</h1>
        <?php if(session()->has('message') && session()->get('success')): ?>
            <div style="color:green;"><?php echo e(session()->get('message')); ?></div>
        <?php else: ?>
            <?php var_dump(session()->get("listUser"))?>
            <div style="color:red;"><?php echo e(session()->get('message')); ?></div>
        <?php endif; ?>
        <div>
            Form laravel JANGAN LUPA PAKAI CSRF
            <form action="<?php echo e(route('registing')); ?>" method="post">
                <?php echo csrf_field(); ?>
                Username <br>
                <input type="text" name="username" id="">

                Password <br>
                <input type="password" name="password" id="">

                <button>Register</button>
            </form>
            <a href="/user/login">go to Login</a>
        </div>
    </div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\tutor_BWP\tutorW7\resources\views/register.blade.php ENDPATH**/ ?>