<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>

    <style>
        body{
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }

        form{
            display: flex;
            flex-direction: column;
        }

        #formulir{
            margin: 10%;
        }
    </style>
</head>
<body>
    <div id="formulir">
        <h1>Login</h1>
        <?php if(session()->has('message')): ?>
            <div style="color:red;"><?php echo e(session()->get('message')); ?></div>
        <?php endif; ?>
        <div>
            Form laravel JANGAN LUPA PAKAI CSRF
            <form action="<?php echo e(route('doLogin')); ?>" method="post">

                <?php echo csrf_field(); ?>
                Username <br>
                <input type="text" name="username" id="">

                Password <br>
                <input type="password" name="password" id="">

                <button>Login</button>
            </form>
            <a href="/user/register">Register</a>
        </div>
        <?php dd(request()->cookie())?>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\tutor_BWP\tutorW7\resources\views/login.blade.php ENDPATH**/ ?>