import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  number: 0,
  number2: 0,
  listNumbers : []
};

export const numberSlice = createSlice({
  name: "number",
  initialState,
  reducers: {
    addNumber: (state, action) => {
      state.number += action.payload;
    },
    addOne: (state) => {
      state.number += 1;
    },
    pushNumber: (state,action)=>{
      state.listNumbers.push(action.payload)
    }
  },
});

export const { addNumber, addOne, pushNumber } = numberSlice.actions;

export default numberSlice.reducer;
