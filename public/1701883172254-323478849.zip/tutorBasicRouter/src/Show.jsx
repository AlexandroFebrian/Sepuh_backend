import React from 'react'
import { useSelector } from 'react-redux'
import { Link } from "react-router-dom"
const Show = () => {
    const number = useSelector((state)=>state.number.number)
    const listNumbers = useSelector((state)=>state.number.listNumbers)

    return (
    <div>
        <h1>Show</h1> 
        <Link to="/show"> <button>Show</button></Link>
        <Link to="/add"> <button>Add</button></Link>
        <p>{number}</p>
        
        <div>Ini array</div>
        {listNumbers.map((num, index)=>{
            return <div key={index}>{num}</div>
        })}
    </div>
  )
}

export default Show