import { Link } from "react-router-dom"
function App() {
  return (
    <>
      <div>
        Ini App <br />
        <Link to="/show"> <button>Show</button></Link>
        <Link to="/add"> <button>Add</button></Link>
      </div>
    </>
  )
}

export default App
