import React from 'react'
import { Link } from "react-router-dom"
import { useDispatch } from 'react-redux'
import { addNumber, pushNumber } from './redux/numberSlice'

const Add = () => {
  const dispatch = useDispatch()
  const tambah = ()=>{
    dispatch(addNumber(1))
  }
  const push = ()=>{
    dispatch(pushNumber(1))
  }
  return (
    <div>
      
      <h1>Add</h1> 
        <Link to="/show"> <button>Show</button></Link>
        <Link to="/add"> <button>Add</button></Link>
      <br />
      <button onClick={tambah}>Tambah</button>
      <button onClick={push}>Push</button>
    </div>
  )
}

export default Add